const products = [
  { id: 1, name: "Balm para Barba", price: 49.90, image: "https://via.placeholder.com/200x150?text=Balm" },
  { id: 2, name: "Pomada Modeladora", price: 39.90, image: "https://via.placeholder.com/200x150?text=Pomada" },
  { id: 3, name: "Shampoo para Barba", price: 29.90, image: "https://via.placeholder.com/200x150?text=Shampoo" }
];

let cart = [];

function renderProducts(filter = "") {
  const container = document.getElementById("products");
  container.innerHTML = "";
  products
    .filter(p => p.name.toLowerCase().includes(filter.toLowerCase()))
    .forEach(product => {
      const div = document.createElement("div");
      div.className = "product";
      div.innerHTML = `
        <img src="${product.image}" alt="${product.name}" width="100%" />
        <h2>${product.name}</h2>
        <p>R$ ${product.price.toFixed(2)}</p>
        <button onclick="addToCart(${product.id})">Adicionar ao Carrinho</button>
      `;
      container.appendChild(div);
    });
}

function addToCart(productId) {
  const product = products.find(p => p.id === productId);
  const item = cart.find(i => i.id === productId);
  if (item) {
    item.quantity += 1;
  } else {
    cart.push({ ...product, quantity: 1 });
  }
  updateCart();
}

function updateCart() {
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  document.getElementById("cart-count").textContent = cartCount;
  document.getElementById("cart-items").innerHTML = cart.map(item =>
    `<li>${item.name} x${item.quantity}</li>`
  ).join("");
  document.getElementById("cart-total").textContent = `Total: R$ ${total.toFixed(2)}`;
}

function clearCart() {
  cart = [];
  updateCart();
}

function searchProducts() {
  const term = document.getElementById("search").value;
  renderProducts(term);
}

renderProducts();
